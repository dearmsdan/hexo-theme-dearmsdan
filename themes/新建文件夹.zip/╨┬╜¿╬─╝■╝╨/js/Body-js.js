// JavaScript Document
var color =$（".class[颜色=red]"）
if
color. CSS("background","white")
Else
color. CSS("background","white")