---
title: 留言板
date: 18:59 2019/11/25
layout: Permalinks
permalink: valine.html
---

留言板，请大佬任意发炎  
如果有什么问题  
或者反馈都可以   
发送在评论区   
或者在 [码云](https://gitee.com/zhd99/zhd99/issues)、 [GitHub](https://github.com/ZHD99/hexo-theme-dearmsdan/issues)用 Issues 方式发送给我哦   
添加友链[传送带 ](/link.html)

