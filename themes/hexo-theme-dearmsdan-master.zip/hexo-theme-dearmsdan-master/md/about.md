---
title: about
date: 18:59 2019/11/25
layout: Permalinks
permalink: about.html
---



>> # 关于  

基于Bootstrap 框架  
HEXO 强力驱动的 一个  宝钻蓝 色调，给你一种空灵的感觉  
  [hexo-theme-dearmsdan](https://github.com/ZHD99/hexo-theme-dearmsdan)  
代码已开源，Github 随意下载 ~

主题文档未完全，了解功能全靠注释，本站源码配置文件有注释，有缘人最好能帮忙补上文档

文档： http://docs.dearmsdan.com/

  









------

