<div align="right">
  Language:
  中文
</div>
<p align="center">
  </p>
<p align="center">
  </p>

<h1 align="center">HEXO 主题 宝钻蓝色 </h1>
<h3 align="center">给你一种空灵的感觉 </h3><br/>
<p align="center">
   <a href="https://nodejs.org"><img src="https://img.shields.io/badge/node-%3E= v10-green?style=flat-square"></a>
  <a href="https://hexo.io"><img src="https://img.shields.io/badge/hexo-%3E=4.0.0-blue?style=flat-square&logo=hexo"></a>
  <a href="https://github.com/ZHD99/hexo-theme-dearmsdan/blob/master/LICENSE"><img src="https://img.shields.io/badge/license-%20MIT -orange?style=flat-square&logo=gnu"></a>
 <a href="https://codeload.github.com/ZHD99/hexo-theme-dearmsdan/zip/master"><img src="https://img.shields.io/badge/downloads-772KB-brightgreen?style=flat-square"></a> 
  <br/>
</p>
<br/>

.  <br/>

## 特性

- 基于Bootstrap+jQuery
- 文档有基本介绍，主题config注释有功能介绍
- PJAX
- 全文搜索、调试功能
- 自定义背景设置(图片、图片特效、视频)
- 自定义一级、二级目录
- 自定义社交按钮
- 自定义音乐播放器
- 置顶功能
- 离线访问功能
- 首页 自定义排版
- 自定义主题颜色
- 节日特效  D :)  diy
- 可自定义设置背景特效canvas
- 自定义悬浮文章上变色
- 自定义外部链接拦截提示
- 支持 valine 评论系统
- 支持config配置友情链接
- 、自定义作者、底部时间统计等等...

## 安装

dearmsdan 主题使用`ejs`模板引擎开发

1. 拷贝主题到`themes`目录

```
cd themes
git clone https://github.com/ZHD99/hexo-theme-dearmsdan.git dearmsdan
```

2. 修改主程序的`_config.yml`文件

```
theme: dearmsdan
```

就可以运行了，`hexo s`



## 基本附加

为了方便修改和使用，我把`关于、留言板、友情链接、时间轴、404页面`都以永久链接的方式添加  
如果你需要的话可能会使用到这些内容，我提供了示例页面 

添加`关于、留言板、友情链接、时间轴、404`  

- 找到您的主题dearmsdan下的md 文件下的4个 *.md 格式 
- 把这4个文件复制到node_modules  同目录下的 source 文件夹下 (说白了就是你写文章的地方)

如果不会我有个无声视频建议2倍速https://www.bilibili.com/video/BV1bT4y1L77L



## 展示

 [梦窗 AI_blog](https://mymengchuang.gitee.io/)    
 [ ye\'s universe](https://beamaster.top/)   
[ r0ya1\'s blog](https://r0ya1.gitee.io/)     

http://s-bj.dearmsdan.com/  
http://m-bj.dearmsdan.com/  
http://c-bj.dearmsdan.com/   

