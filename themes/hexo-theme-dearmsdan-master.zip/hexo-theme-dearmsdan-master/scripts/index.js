/* global hexo */

// Welcome Message
require('../source/js/welcome');

